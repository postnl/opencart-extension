<?php
/**
 * Copyright (c) De Webmakers
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

$_['label_number']              = 'Nummer';
$_['label_addition']            = 'Toevoeging';
$_['label_loading']             = 'Een moment a.u.b.';
$_['label_noresults']           = 'Geen resultaten gevonden';
$_['label_chosen']              = 'Gekozen adres';
$_['label_timeout']             = 'Server niet bereikbaar';
$_['label_reset']               = 'Zoek opnieuw';