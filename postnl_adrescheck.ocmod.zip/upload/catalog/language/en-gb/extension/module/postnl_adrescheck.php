<?php
/**
 * Copyright (c) De Webmakers
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

$_['label_number']              = 'Number';
$_['label_addition']            = 'Addition';
$_['label_loading']             = 'One moment please';
$_['label_noresults']           = 'No results found';
$_['label_chosen']              = 'Chosen address';
$_['label_timeout']             = 'Cannot reach server';
$_['label_reset']               = 'Search again';
