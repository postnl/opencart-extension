<?php
include_once(__DIR__."/../../module/postnl_adrescheck.php");

class ControllerExtensionModulePostnlAdrescheck extends ControllerModulePostnlAdrescheck
{

}
